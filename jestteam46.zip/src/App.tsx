import React from "react";

import "./App.css";
import Counter from "./exercise/03-ReactDom/Counter";

function App() {
  return (
    <>
      <h1>Software Quality</h1>
      <Counter />
    </>
  );
}

export default App;
