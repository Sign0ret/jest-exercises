export function reverseString(str: string): string {
  return str.split("").reverse().join("");
}

export function toUpperCase(str: string): string {
  return str.toUpperCase();
}

export function toLowerCase(str: string): string {
  return str.toLowerCase();
}
